import SearchForm from './SearchForm'

function App() {
  return <SearchForm />
}

export default App
